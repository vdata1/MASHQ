# mashq-node-red-minimal

A **self-contained, minimal** reproduction of the Node-RED runtime-fingerprinting
+ runtime-targeted takedown from the MASHQ paper. Everything needed is in this one
directory; there are no references outside it.

Three **identical** Node-RED 4.0.9 instances run on three JS runtimes — Node.js,
Deno, and Bun. An attacker who can submit JavaScript to a `function` node (via the
Admin API) **fingerprints the underlying runtime from sandbox output alone**, then
submits **one** runtime-targeted payload that crashes **only** the intended
deployment while the other two keep serving. The **detonation gadget** is made
entirely of legitimate reflection primitives (`Object.getPrototypeOf` +
`Object.defineProperty` + a throwing getter) — no `process`, `require`,
`constructor`, `Function`, or `eval` token appears in it, so a code-injection
denylist has nothing to match. (The fingerprint that precedes it is likewise benign;
matching the paper's Fig. 7, it reads `Error().stack[0].constructor` — an ordinary
property access, not the `constructor(...)()` code-execution gadget a denylist
targets.)

## What you need

- **Docker** (with `docker compose`) — builds/runs the three victim containers.
- **A host `node`** — runs the attacker driver only. The driver uses just Node
  builtins (`http`, `child_process`, `fs`); there is nothing to `npm install`.

## Reproduce (one command each)

```bash
docker compose up -d --build     # build + start Node-RED on all three runtimes (first build ~1-2 min)
node driver.mjs                  # Stage 1 fingerprint -> Stage 2 3x3 matrix -> writes results.json
docker compose down -v           # stop + clean up
```

Compare the generated `results.json` against `expected-results.json`.

### Expected output (deterministic)

```
fingerprint accuracy: 3/3     targetedDetonation: true     stealth: true

3x3 discrimination matrix (rows = payload, cols = deployment)
           node    deno    bun
  node     DOWN    UP      UP
  deno     UP      DOWN    UP
  bun      UP      UP      DOWN
```

A clean diagonal: each payload downs only its target; off-diagonal stays UP (stealth).

## Interactive demo — step by step 

The demo flows are **pre-loaded** into every instance (baked in as Node-RED's
`flows.json`) — nothing to import. Two clicks show the whole result: identify the
runtime, then take it down. The three instances are byte-for-byte identical images;
only the JS runtime underneath differs.

**1. Start the three victims** (first build ~1–2 min; later starts are seconds):

```bash
cd mashq-node-red-minimal
docker compose up -d --build
```

**2. Open a Node-RED editor** in your browser (no login):

| runtime | editor URL |
|---|---|
| Node 24.1.0 | http://127.0.0.1:1881/ |
| Deno 2.3.3  | http://127.0.0.1:1882/ |
| Bun 1.2.14  | http://127.0.0.1:1893/ |

You land on the flow tab **"MASHQ · fingerprint + takedown"** with two inject
buttons already wired up. (Open the **debug sidebar** first: the bug icon, top-right.)

**3. Fingerprint the runtime (safe).** Click the little button on the left edge of
the **① Fingerprint (safe)** node. The debug sidebar prints the runtime it inferred
— from benign JS only (a CallSite-constructor probe + an Intl/ICU currency signal; the paper's Fig. 7) — and
the function node shows a green `runtime = …` status. Repeatable; changes nothing.

| you opened… | debug sidebar shows |
|---|---|
| :1881 | `{"guess":"node","callsite":false,"afn":0,"process_hidden":"undefined",…}` |
| :1882 | `{"guess":"deno","callsite":true, "afn":0, …}` |
| :1893 | `{"guess":"bun", "callsite":true, "afn":2, …}` |

**4. (Optional) watch it die in real time.** In a second terminal, tail the log for
the instance you opened:

```bash
docker compose logs -f nr-node     # or nr-deno / nr-bun
```

**5. Take the instance down.** Click the button on the **② Detonate (takes THIS
instance down)** node. It self-targets using the fingerprint, poisons a *host*
intrinsic through `msg`'s prototype, and the instance stops serving — the editor
banner turns to **"Lost connection to server, reconnecting…"**. In the log tail you
see the uncaught exception:
   - **Node** → `TypeError: util.log is not a function … process._fatalException … Node.js v24.1.0` (process exits)
   - **Bun**  → `[red] Uncaught Exception: TypeError: Attempted to assign to readonly property.` (process exits)
   - **Deno** → `TypeError: Cannot set property _readableState … which has only a getter` on every request (process stays up but serves nothing — its `node:http` shim is more robust)

The **other two instances keep serving** — confirm by clicking ① in their editors.

**6. Recover** the downed instance to a clean, pre-loaded state (fresh process,
baked flows reloaded):

```bash
bash reset.sh node      # (or: deno | bun | any subset | no args = all three)
```

**7. Stop everything** when done:

```bash
docker compose down -v
```

> More confirmation angles — a no-browser CLI probe (`inspect.mjs`), a single-shot
> detonation with log capture, and the full automated 3×3 matrix — are in
> [`INSPECT.md`](INSPECT.md).

## How it works

1. **Victim** — stock `node-red@4.0.9`, three identical images
   (`Dockerfile.{node,deno,bun}`, pinned Node 24.1.0 / Deno 2.3.3 / Bun 1.2.14),
   locked down by `settings.cjs` (`functionGlobalContext:{}`,
   `functionExternalModules:false`, no adminAuth).
2. **Submission surface** — the driver deploys `http in(/run) → function(eval) →
   http response` via `POST /flows`, then `POST /run {code}` evals attacker code in
   the function-node sandbox. Health is checked via `GET /settings` (the Express
   admin server, which always answers).
3. **Stage 1 — fingerprint (benign, paper Fig. 7).** In the default sandbox
   `process`/`Deno`/`Bun` are `undefined` and `Function('return process')()` throws,
   so *direct* introspection is denied. The runtime is still identified from two
   benign signals:
   - a **CallSite-constructor probe** (`Error.prepareStackTrace` →
     `Error().stack[0].constructor`, then `new C(C,6).toString()`): it throws on
     **Node** but not Deno/Bun → `callsite=false` ⇒ **Node**.
   - otherwise an **Intl/ICU** signal — the `AFN` currency's `minimumFractionDigits`
     is `2` on **Bun**, `0` on **Deno**. Decision: `!callsite ? node : (afn===2 ? bun : deno)`.
4. **Stage 2 — detonate (process-free).** The function node injects the **host**
   object `msg`; `Object.getPrototypeOf(msg)` **is** the host realm's
   `Object.prototype`. Defining a throwing accessor on it poisons a host intrinsic
   with no realm crossing:
   - **Node** → poison `chunkedEncoding` (Node's native `http` writes it; Deno's
     shim and Bun don't) — *intrinsic*.
   - **Bun** → poison `headers` (Bun's `http` reads it on a plain object) — *intrinsic*.
   - **Deno** → **fingerprint-gated**: `if (<Fig. 7 fingerprint> === 'deno'){…}`
     then a universal `node:http` breaker (`_readableState`). There is **no Deno-only
     intrinsic crash** on Node-RED — Deno's `node:http` shim is a strict subset of
     Node's native http — so a Deno takedown must be gated on the fingerprint and
     is a literal no-op on Node/Bun.

   Detonation fires on Node-RED's own ambient HTTP workload (the `http response`
   path); the process dies with an uncaught exception — a valid availability DoS.

## Files

| file | purpose |
|---|---|
| `docker-compose.yml` | three victims: Node `:1881`, Deno `:1882`, Bun `:1893` (→ container `:1880`) |
| `Dockerfile.node` / `.deno` / `.bun` | pinned Node-RED 4.0.9 images per runtime |
| `settings.cjs` | locked-down Node-RED config (shared by all three; `.cjs` so Deno loads it as CommonJS) |
| `driver.mjs` | attacker driver: fingerprint → 3×3 matrix → `results.json` |
| `expected-results.json` | reference output to diff against |
| `reset.sh` | restart victims to a clean state (`bash reset.sh [node\|deno\|bun]…`) |
| `flows.json` | the pre-loaded demo flows, **baked into each image** (① Fingerprint / ② Detonate buttons) |
| `demo-flow.json` | identical copy of `flows.json`, for manual **Import** into a non-baked instance |
| `inspect.mjs` | live inspector: raw fingerprint per instance (non-destructive), or `detonate` with log capture |
| `INSPECT.md` | four ways to inspect the running instances (CLI probe, detonation, log tail, browser) |
| `finding-the-poc.md` | line-level map from the paper's claims to `driver.mjs` |

## Notes / gotchas

- **Pinned images are required.** Current-latest runtimes do not reproduce the
  clean diagonal; the pins above do.
- **Deno settings must be `.cjs`.** Deno's npm loader treats a `.js` settings file
  as ESM and `module.exports` throws.
- **Bun `http response` answers once per process.** Bun 1.2.14's Node-RED
  `http response` node replies only to the *first* request per process lifetime
  (later ones log `ERR_HTTP_HEADERS_SENT` and hang; the Admin API is unaffected).
  The driver accommodates this by structuring every interaction as
  *restart → deploy → exactly one `/run` → health via `/settings`*.

## Safety & scope

Entirely local, self-hosted Node-RED; no external targets, no network egress. The
payloads are already-disclosed prototype-pollution behaviors against instances you
run yourself. Research PoC only.
