# Inspecting the live instances (reviewer confirmation)

The flows are **pre-loaded** into all three instances — no import step. Start the
stack, open a link, click a button. Everything below assumes:

```bash
docker compose up -d --build
```

Editors (no login): **Node http://127.0.0.1:1881/** · **Deno http://127.0.0.1:1882/** · **Bun http://127.0.0.1:1893/**

---

## 1. Click a button in the pre-loaded flow (what to hand a reviewer)

Open any editor URL. The tab **"MASHQ · fingerprint + takedown"** is already there
with two inject buttons (click the tab on the left of the inject node):

- **① Fingerprint (safe)** — click it. The **debug sidebar** (top-right, bug icon)
  prints the runtime, and the function node shows a green `runtime = …` status.
  Repeatable, non-destructive. Live-captured values, one per instance:

  ```
  :1881 (Node) → {"guess":"node","callsite":false,"afn":0,"process_hidden":"undefined", ...}
  :1882 (Deno) → {"guess":"deno","callsite":true, "afn":0, ...}
  :1893 (Bun)  → {"guess":"bun", "callsite":true, "afn":2, ...}
  ```

- **② Detonate (takes THIS instance down)** — click it. The instance poisons a host
  intrinsic (self-targeted via the fingerprint) and stops serving; the editor shows
  **"Lost connection to server, reconnecting…"**. Recover with
  `docker compose restart nr-<rt>` (or `bash reset.sh <rt>`).
  - On **Node** and **Bun** the process **exits** with an uncaught exception
    (container goes `Exited`).
  - On **Deno** the process **stays up but every HTTP request fails** — Deno's
    `node:http` shim catches the per-request throw, so it's an availability DoS
    without a process exit. (This is the paper's "Deno shim is a strict subset /
    more robust" point, visible live.)

That's the whole demonstration in two clicks. §2–4 are extra confirmation angles.

## 2. Watch the takedown in the container logs

```bash
docker compose logs -f nr-node        # (or nr-deno / nr-bun) — 2nd terminal, then click ②
```

- Node → `TypeError: util.log is not a function … at process._fatalException … Node.js v24.1.0`
- Bun  → `[red] Uncaught Exception: TypeError: Attempted to assign to readonly property.`
- Deno → repeated `TypeError: Cannot set property _readableState … which has only a getter`
         at `new IncomingMessageForServer` (every request, process alive)

## 3. Live CLI probe — `inspect.mjs` (no browser)

```bash
node inspect.mjs                    # non-destructive: raw fingerprint JSON per instance (leaves all UP)
node inspect.mjs detonate node      # fire node's payload at node: DOWN + log capture
node inspect.mjs detonate node deno # fire node's payload at deno: inert, stays UP (stealth)
```

Submits the **exact** `PROBE`/payloads from `driver.mjs` (extracted at runtime, so
there's no second copy to drift) against the running instances.

## 4. Full automated matrix — `driver.mjs`

```bash
node driver.mjs                     # fingerprint 3/3 + 3x3 payload×deployment matrix -> results.json
```

The end-to-end paper result. Note this **redeploys** each instance's flows (via
`POST /flows`), replacing the pre-loaded demo in the running container; restore it
with `docker compose down && docker compose up -d` (or a rebuild), which reloads the
baked `flows.json`.

---

### Recovering an instance

Any `②`/detonation leaves that instance down or dirty. One command restores a clean,
pre-loaded instance (fresh process, baked flows reloaded):

```bash
bash reset.sh                # all three
bash reset.sh node deno      # a subset
```
