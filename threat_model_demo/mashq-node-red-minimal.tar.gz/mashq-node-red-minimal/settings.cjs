// Locked-down Node-RED settings for the PoC victim. Written as explicit CommonJS
// (.cjs) so Deno's npm-compat loader treats it as CJS rather than ESM — a plain
// .js here throws "module is not defined" under Deno.
//
// Success criterion 1: the function-node sandbox must NOT expose process / Deno /
// Bun, forcing the attacker into *behavioral* fingerprinting (see README).
module.exports = {
  uiPort: process.env.PORT || 1880,
  functionGlobalContext: {},        // no globals injected into the sandbox
  functionExternalModules: false,   // function nodes may not require() modules
  flowFile: 'flows.json',
  userDir: '/data',
  // No adminAuth: the Admin API is open. That open /flows endpoint IS the
  // attacker's code-submission surface for this PoC (entirely local).
  logging: { console: { level: 'info', metrics: false, audit: false } },
  editorTheme: { tours: false },
};
