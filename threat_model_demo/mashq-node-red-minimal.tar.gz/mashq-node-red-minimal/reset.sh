#!/usr/bin/env bash
# Restart the Node-RED victims to a clean state and wait until healthy.
#   bash reset.sh            # all three
#   bash reset.sh node       # just Node   (also: deno | bun, or any subset)
# (Written for macOS's default bash 3.2 — no associative arrays.)
set -uo pipefail
cd "$(dirname "$0")"

svc_of()  { case "$1" in node) echo nr-node;; deno) echo nr-deno;; bun) echo nr-bun;; *) echo "";; esac; }
port_of() { case "$1" in node) echo 1881;;   deno) echo 1882;;   bun) echo 1893;;   *) echo "";; esac; }

if [ $# -eq 0 ]; then targets="node deno bun"; else targets="$*"; fi

svcs=""
for t in $targets; do
  s=$(svc_of "$t")
  [ -n "$s" ] || { echo "unknown runtime '$t' (use: node deno bun)"; exit 1; }
  svcs="$svcs $s"
done

docker compose up -d >/dev/null
echo "[reset] restarting: $targets"
docker compose restart $svcs >/dev/null

for t in $targets; do
  p=$(port_of "$t")
  printf "  %-4s :%s  " "$t" "$p"
  ok=DOWN
  for i in $(seq 1 60); do
    curl -fs "http://127.0.0.1:$p/settings" >/dev/null 2>&1 && { ok=UP; break; }
    sleep 1
  done
  echo "$ok"
done
echo "[reset] done — node http://127.0.0.1:1881  deno http://127.0.0.1:1882  bun http://127.0.0.1:1893"
