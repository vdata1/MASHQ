// Phase 1: install each package into its own isolated directory.
// Runs with network access. --ignore-scripts: the require/import-time channel is
// measured, not npm lifecycle scripts.
import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";

const DATA = JSON.parse(fs.readFileSync("/runner/AugTop1K_npm.json", "utf8"));
const LIMIT = Number(process.env.LIMIT || 0);
const CONC = Number(process.env.INSTALL_CONC || 12);
const TIMEOUT_MS = Number(process.env.INSTALL_TIMEOUT_MS || 300000);

const pkgs = LIMIT ? DATA.packages.slice(0, LIMIT) : DATA.packages;
const ROOT = "/work/pkgs";
const PROBE_SRC = fs.readFileSync("/runner/probe_one.mjs", "utf8");

fs.mkdirSync(ROOT, { recursive: true });
const out = fs.createWriteStream("/work/install.jsonl", { flags: "w" });

export const dirFor = (name) => name.replace(/^@/, "at-").replace(/\//g, "__");

function run(cmd, args, opts) {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { ...opts, stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "", stderr = "", timedOut = false;
    const timer = setTimeout(() => { timedOut = true; child.kill("SIGKILL"); }, TIMEOUT_MS);
    child.stdout.on("data", (d) => { if (stdout.length < 20000) stdout += d; });
    child.stderr.on("data", (d) => { if (stderr.length < 20000) stderr += d; });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code, stdout, stderr, timedOut });
    });
    child.on("error", (e) => {
      clearTimeout(timer);
      resolve({ code: -1, stdout, stderr: String(e), timedOut });
    });
  });
}

let done = 0;
async function installOne(p) {
  const dir = path.join(ROOT, dirFor(p.name));
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(
    path.join(dir, "package.json"),
    JSON.stringify({ name: "probe-host", version: "1.0.0", private: true }, null, 2)
  );
  fs.writeFileSync(path.join(dir, "__probe.mjs"), PROBE_SRC);

  const r = await run(
    "npm",
    ["install", `${p.name}@${p.version}`, "--ignore-scripts", "--no-audit", "--no-fund", "--loglevel=error"],
    { cwd: dir, env: { ...process.env, npm_config_update_notifier: "false" } }
  );

  const installed = fs.existsSync(path.join(dir, "node_modules", ...p.name.split("/"), "package.json"));
  const ok = r.code === 0 && installed;
  const err = ok ? "" : (r.stderr || r.stdout || "").slice(0, 800);
  // Prebuilt native packages gated to another os/cpu (e.g. @esbuild/linux-x64 on
  // arm64) cannot be installed here at all. That is an artifact of the host
  // architecture, not a runtime compat signal, so it is tracked separately and
  // excluded from the compat denominator.
  const errClass = ok
    ? ""
    : /EBADPLATFORM|Unsupported platform|notsup/i.test(err)
      ? "platform"
      : r.timedOut
        ? "timeout"
        : "other";
  const rec = {
    rank: p.rank,
    package: p.name,
    version: p.version,
    weeklyDownloads: p.weeklyDownloads,
    install_ok: ok,
    install_timeout: r.timedOut,
    install_err_class: errClass,
    install_err: err,
  };
  out.write(JSON.stringify(rec) + "\n");
  done++;
  if (done % 25 === 0 || done === pkgs.length) {
    console.log(`install ${done}/${pkgs.length}`);
  }
  return rec;
}

// Simple bounded worker pool.
const queue = [...pkgs];
const workers = Array.from({ length: Math.min(CONC, queue.length) }, async () => {
  while (queue.length) await installOne(queue.shift());
});
await Promise.all(workers);
out.end();

const lines = fs.readFileSync("/work/install.jsonl", "utf8").trim().split("\n").filter(Boolean);
const ok = lines.filter((l) => JSON.parse(l).install_ok).length;
console.log(`INSTALL DONE: ${ok}/${pkgs.length} installed`);
