#!/bin/sh
# Build + run all three phases, then copy outputs to ./out/. Set LIMIT for a smoke run:
#   ./run.sh            # full top-1000
#   LIMIT=25 ./run.sh   # top 25 only
set -eu
cd "$(dirname "$0")"
IMG=npmscan-min:latest
VOL=npmscan-work
LIMIT="${LIMIT:-0}"

docker build -t "$IMG" .
docker volume create "$VOL" >/dev/null

echo "[phase 1] install (LIMIT=$LIMIT)"
docker run --rm -e LIMIT="$LIMIT" -v "$VOL":/work "$IMG" node /runner/install.mjs
echo "[phase 2] probe (network off)"
docker run --rm -v "$VOL":/work --network none "$IMG" node /runner/probe.mjs
echo "[phase 3] summarize"
docker run --rm -v "$VOL":/work --network none "$IMG" node /runner/summarize.mjs /work

mkdir -p out
docker run --rm -v "$VOL":/work -v "$PWD/out":/out "$IMG" \
  sh -c 'cp /work/summary.json /work/results.csv /work/results.jsonl /work/install.jsonl /work/versions.json /out/'
echo "[done] outputs in ./out/  — headline:"
node -e 'const s=require("./out/summary.json");console.log("  scored:",s.n_scored,"| load-clean all three:",s.headline.load_clean_all_three.pct+"%","| execute all three:",s.execution_reach.all_three_got_control.pct+"%");' 2>/dev/null || true
