# npm cross-runtime *load* compatibility (paper-supporting harness)

A minimal, self-contained harness for the paper's delivery-feasibility experiment: **do
popular npm packages load unmodified across Node.js, Deno, and Bun?** It installs
the top-1000 npm packages once with `npm`, then loads that *identical*
`node_modules` tree under all three runtimes and records whether each package's
top-level code executes.

The harness runs the three-runtime, shared-dependency-tree comparison (Variant A)
reported in the paper: one npm-installed `node_modules` tree loaded under Node.js,
Deno, and Bun.

## Paper figures this reproduces

Of the top **1,000** most-downloaded npm packages, the **938** that ship executable
JavaScript:

| metric | figure | meaning |
|---|---|---|
| load clean on all three | **98.4 %** (923/938) | conservative compatibility claim — loaded with *no error* on Node, Deno, and Bun |
| execute on all three | **99.0 %** (929/938) | delivery claim — top-level code got control (loaded, or ran then threw) |
| identical across runtimes | **99.6 %** | same outcome on every runtime; only a handful diverge |

Runtimes (pinned): **Node.js 26.5.0 · Deno 2.9.1 · Bun 1.3.14**.

## Method

Install once with npm (`--ignore-scripts --no-audit --no-fund`) into a **fresh
per-package directory**, pinned to the version in `AugTop1K_npm.json`, then load
*those same bits* under each runtime. This isolates "does top-level code run under
this runtime's compat layer" from "can this runtime's package manager resolve the
package." One probe file (`probe_one.mjs`) is copied into each package dir and run
identically by every runtime, so bare-specifier resolution always resolves against
that dir's `node_modules`:

```
node                                    ./__probe.mjs
deno run -A --node-modules-dir=manual   ./__probe.mjs
bun                                     ./__probe.mjs
```

The probe attempts `await import(pkg)` and falls back to `require(pkg)` for CJS-only
packages. **Success = the entry point loaded and its top-level code ran without
throwing.** 30 s timeout; the load phase runs with `--network none`.

> **Deno flag.** `--node-modules-dir=manual` consumes the existing npm-installed
> tree. `auto` would make Deno build its *own* tree from the registry — a different
> experiment, and one that reports 0 % under `--network none`.

## Reproduce

```sh
docker build -t npmscan-min:latest .
docker volume create npmscan-work

# Phase 1 — install (needs network)
docker run --rm -v npmscan-work:/work npmscan-min:latest node /runner/install.mjs

# Phase 2 — load under each runtime (network OFF)
docker run --rm -v npmscan-work:/work --network none npmscan-min:latest node /runner/probe.mjs

# Phase 3 — aggregate -> /work/summary.json + /work/results.csv
docker run --rm -v npmscan-work:/work --network none npmscan-min:latest node /runner/summarize.mjs /work
```

Copy the outputs out of the volume when done:

```sh
docker run --rm -v npmscan-work:/work -v "$PWD/out":/out npmscan-min:latest \
  sh -c 'cp /work/summary.json /work/results.csv /work/results.jsonl /work/versions.json /out/'
```

**Smoke run:** set `-e LIMIT=25` on the install step to scan only the top 25.

### See one real probe

```sh
docker run --rm -v npmscan-work:/work -v "$PWD/example":/example \
  --network none npmscan-min:latest sh /example/probe-demo.sh semver
```

Reads the real installed tree and runs the actual probe under all three runtimes.

## Denominators (why 1000 → 938)

- **1000 attempted → 991 installed.** The 9 failures are x64-only prebuilt native
  binaries (`@esbuild/linux-x64`, `@rollup/rollup-linux-x64-*`, `@img/sharp-linux-x64`,
  `lightningcss-linux-x64-*`, `@tailwindcss/oxide-linux-x64-*`) that npm refuses on
  arm64 — an architecture artifact, not a runtime signal. (On an x64 host, the
  mirror-image arm64-only set drops instead.)
- **991 installed → 938 scored.** 53 packages ship only TypeScript declarations
  (`@types/*`, `type-fest`, `csstype`, `undici-types`) with no JavaScript entry
  point, so they cannot execute on *any* runtime by construction.
- Of the 938, ~11 fail on **every** runtime (no importable root entry, or a
  deliberately-refused root import like `@noble/hashes`, or an uninstalled peer
  dependency). These are uniform, not compat failures; counting them against
  the rate is the conservative choice the 98.4 % headline makes.

## Files

| Path | Contents |
|---|---|
| `Dockerfile` | Node 26.5.0 base + pinned Deno/Bun (arch-selected at build) |
| `AugTop1K_npm.json` | the dataset: top-1000 npm packages, pinned versions + integrity hashes |
| `install.mjs` | Phase 1 — isolated per-package `npm install --ignore-scripts` |
| `probe_one.mjs` | the load probe copied into every package dir (import → require fallback) |
| `probe.mjs` | Phase 2 — load each package under Node/Deno/Bun; classify each outcome |
| `summarize.mjs` | Phase 3 — `results.jsonl` → `summary.json` + `results.csv` |
| `example/probe-demo.sh` | one worked probe across all three runtimes |

Outputs land in the Docker volume: `summary.json` (all aggregate figures + versions),
`results.jsonl` / `results.csv` (one row per package), `install.jsonl`, `versions.json`.

## Caveats

- Load success ≠ functional parity. This measures *delivery*, not use; test suites
  are not run.
- Bare import does not exercise lazily-loaded submodules. The attacker controls
  payload placement, so this bounds — acceptably — what the number covers.
- Popularity is download-weighted; malicious packages are typically *not* popular.
  The figure says "the compat substrate is broad," not "popular packages are malicious."
- `--ignore-scripts` excludes npm lifecycle scripts (a Node-only, install-time
  channel); the measured channel is the cross-runtime require/import path.
- Numbers were produced on an **arm64** host (as in the paper). The exact
  native-package exclusions differ by architecture; the compat rate does not
  materially.
