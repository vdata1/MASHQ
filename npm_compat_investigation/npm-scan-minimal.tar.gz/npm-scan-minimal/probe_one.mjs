// Load probe. Copied into each package's own directory so that bare-specifier
// resolution happens against that directory's node_modules, identically under
// every runtime. Executed as: <runtime> ./__probe.mjs  (cwd = package dir)
//
// Success = the entry point loaded and its top-level code ran without throwing.
// The probe exits explicitly on success: top-level code that starts a server or
// interval would otherwise hold the loop open, and for the delivery claim that code
// has already executed. A `timeout` here therefore means the load itself never
// completed, not merely that the process stayed alive.

const pkg = process.env.PROBE_PKG;

// Emit name/code/message as separate fields. Whether the module got control
// before throwing is decided from the error's *type*, not from its prose: a
// resolution code means it was never located, a SyntaxError means it was located
// but never ran, and anything else (TypeError, ReferenceError, a thrown Error
// from the module body) means top-level code was already executing.
function describe(e) {
  if (!e) return "||";
  const name = (e && e.name) || (e && e.constructor && e.constructor.name) || "";
  const code = (e && e.code) || "";
  const msg = ((e && e.message) || String(e)).split("\n")[0];
  return `${name}|${code}|${msg}`.slice(0, 600);
}

try {
  await import(pkg);
  console.log("PROBE_OK import");
  process.exit(0);
} catch (importErr) {
  // CJS-only packages that don't interop under a given runtime: retry require.
  try {
    const { createRequire } = await import("node:module");
    const require = createRequire(new URL("./__probe.mjs", import.meta.url));
    require(pkg);
    console.log("PROBE_OK require");
    process.exit(0);
  } catch (requireErr) {
    console.error("PROBE_ERR_IMPORT " + describe(importErr));
    console.error("PROBE_ERR_REQUIRE " + describe(requireErr));
    process.exit(1);
  }
}
