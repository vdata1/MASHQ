#!/bin/sh
# Demonstrate one real probe, exactly as the scan ran it, across all three runtimes.
#
#   docker run --rm -v npmscan-work:/work -v "$PWD/example":/example \
#     --network none npmscan-min:latest sh /example/probe-demo.sh <package>
#
# Reads the same /work/pkgs tree the full scan produced, so what you see here is the
# real thing, not a reconstruction. Run the install phase first (see README).

PKG="${1:-semver}"
DIR="/work/pkgs/$(echo "$PKG" | sed 's|^@|at-|; s|/|__|g')"

if [ ! -d "$DIR" ]; then
  echo "No installed package dir for '$PKG' at $DIR"
  echo "Available (first 20):"; ls /work/pkgs 2>/dev/null | head -20
  exit 1
fi

rule() { printf '\n\033[1m── %s \033[0m%s\n' "$1" "$(printf '%.0s─' $(seq 1 $((64 - ${#1}))))"; }

rule "1. package under test"
echo "  name:      $PKG"
echo "  probe dir: $DIR"

rule "2. the package's own entry-point declaration"
node -e '
const fs=require("fs"), p=process.argv[1], d=process.argv[2];
const pj=JSON.parse(fs.readFileSync(d+"/node_modules/"+p+"/package.json","utf8"));
const show=(k)=>console.log("    "+k.padEnd(9)+": "+(pj[k]===undefined?"(absent)":JSON.stringify(pj[k])).slice(0,150));
["type","main","module","exports"].forEach(show);
' "$PKG" "$DIR"

rule "3. the probe (copied verbatim into every package dir)"
sed 's/^/    /' "$DIR/__probe.mjs"

rule "4. running it under each runtime (identical bits, identical probe)"
for spec in \
  "node|node ./__probe.mjs" \
  "deno (2.9.1)|deno run -A --node-modules-dir=manual ./__probe.mjs" \
  "bun (1.3.14)|bun ./__probe.mjs"
do
  label="${spec%%|*}"; cmd="${spec#*|}"
  printf '\n  \033[1m%s\033[0m\n' "$label"
  echo "  \$ cd $DIR && PROBE_PKG=$PKG $cmd"
  out=$(cd "$DIR" && PROBE_PKG="$PKG" $cmd 2>&1)
  code=$?
  echo "$out" | sed 's/^/      /'
  echo "      -> exit $code  [$([ $code -eq 0 ] && echo ok || echo fail)]"
done

rule "5. what the scan recorded for this package"
node -e '
const fs=require("fs");
const rows=fs.readFileSync("/work/results.jsonl","utf8").trim().split("\n").map(JSON.parse);
const r=rows.find(r=>r.package===process.argv[1]);
if(!r){console.log("    (not in results — run probe.mjs first)");process.exit(0)}
for(const [k,v] of Object.entries(r)){
  if(k.endsWith("_err")&&!v) continue;
  console.log("    "+k.padEnd(20)+": "+String(v).split("\n")[0].slice(0,110));
}
' "$PKG"
echo
