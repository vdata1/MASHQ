// Phase 2: load each installed package under every runtime.
// Runs with --network none. The same node_modules bits are loaded by all three
// runtimes, isolating "does top-level code run under this compat layer" from
// "can this runtime's package manager resolve the package".
import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";

const ROOT = "/work/pkgs";
const CONC = Number(process.env.PROBE_CONC || 6);
const TIMEOUT_MS = Number(process.env.PROBE_TIMEOUT_MS || 30000);

// Refreshed into every package dir on each run. The install phase also writes it,
// but re-probing without reinstalling must not run a stale probe.
const PROBE_SRC = fs.readFileSync("/runner/probe_one.mjs", "utf8");

const RUNTIMES = [
  { key: "node", cmd: "node", args: ["./__probe.mjs"] },
  // manual = reuse the npm-installed node_modules as-is. `auto` would make Deno
  // manage its own tree from the registry, which is a different experiment (and
  // reports 0%% under --network none).
  { key: "deno", cmd: "deno", args: ["run", "-A", "--node-modules-dir=manual", "./__probe.mjs"] },
  { key: "bun",  cmd: "bun",  args: ["./__probe.mjs"] },
];

function run(cmd, args, opts, timeoutMs) {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { ...opts, stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "", stderr = "", timedOut = false;
    const timer = setTimeout(() => { timedOut = true; child.kill("SIGKILL"); }, timeoutMs);
    child.stdout.on("data", (d) => { if (stdout.length < 20000) stdout += d; });
    child.stderr.on("data", (d) => { if (stderr.length < 20000) stderr += d; });
    child.on("close", (code) => { clearTimeout(timer); resolve({ code, stdout, stderr, timedOut }); });
    child.on("error", (e) => { clearTimeout(timer); resolve({ code: -1, stdout, stderr: String(e), timedOut }); });
  });
}

// Error codes that mean the module was never located. Node sets these; Bun sets
// MODULE_NOT_FOUND; Deno often throws without a code, hence the message fallback.
const RESOLUTION_CODES = new Set([
  "ERR_MODULE_NOT_FOUND", "MODULE_NOT_FOUND", "ERR_PACKAGE_PATH_NOT_EXPORTED",
  "ERR_UNSUPPORTED_DIR_IMPORT", "ERR_INVALID_MODULE_SPECIFIER", "ERR_PACKAGE_IMPORT_NOT_DEFINED",
  "ERR_UNSUPPORTED_ESM_URL_SCHEME", "ERR_INVALID_PACKAGE_CONFIG", "ENOENT",
]);

// How far did the load get? This is the distinction the delivery claim needs:
// "never got control" vs "got control and then threw".
const STAGE = { not_located: 0, located_not_executed: 1, executed_then_threw: 2 };
function deliveryStage({ name, code, msg }) {
  if (!name && !code && !msg) return null;
  if (RESOLUTION_CODES.has(code)) return "not_located";
  if (name === "SyntaxError") return "located_not_executed";
  // Runtimes that don't set .code on resolution failures. Deliberately narrow:
  // these must be runtime-emitted resolver messages. A package throwing its own
  // Error from its module body (e.g. @noble/hashes' "root module cannot be
  // imported") has executed, and must not be caught here.
  if (/Cannot find (module|package)|Module not found|No "exports" main defined|could not resolve/i.test(msg || ""))
    return "not_located";
  return "executed_then_threw";
}

function parseProbeErr(stderr, marker) {
  const m = new RegExp(`${marker} (.*)`).exec(stderr || "");
  if (!m) return { name: "", code: "", msg: "" };
  const parts = m[1].split("|");
  return { name: parts[0] || "", code: parts[1] || "", msg: parts.slice(2).join("|") };
}

// Classify a failure from stderr. Order matters: the more specific patterns win.
function classify(stderr) {
  const s = stderr || "";
  if (/ERR_MODULE_NOT_FOUND|ERR_PACKAGE_PATH_NOT_EXPORTED|ERR_UNSUPPORTED_DIR_IMPORT|ERR_UNSUPPORTED_ESM_URL_SCHEME|Cannot find module|Cannot find package|Module not found|Could not resolve|Relative import path|unsupported specifier|ERR_INVALID_MODULE_SPECIFIER/i.test(s))
    return "resolution";
  if (/SyntaxError|Unexpected token|Unexpected identifier|Invalid or unexpected token|ERR_REQUIRE_ESM|ERR_REQUIRE_ASYNC_MODULE|Cannot use import statement/i.test(s))
    return "syntax";
  if (/is not implemented|not implemented in (Deno|Bun)|NotSupported|Unsupported|is not a function|is not defined|Cannot read propert(y|ies) of (undefined|null)|undefined is not an object|no such built-in|ERR_UNKNOWN_BUILTIN_MODULE|ERR_INVALID_ARG|process\.binding|deno:|Deno\./i.test(s))
    return "missing_api";
  return "other";
}

// ESM if the package declares module semantics or ships an ESM entry.
function entryType(pkgJson) {
  if (!pkgJson) return "unknown";
  if (pkgJson.type === "module") return "esm";
  if (typeof pkgJson.module === "string") return "esm";
  const ex = pkgJson.exports;
  const hasImport = (node, depth = 0) => {
    if (!node || depth > 6) return false;
    if (typeof node === "string") return false;
    if (Array.isArray(node)) return node.some((n) => hasImport(n, depth + 1));
    if (typeof node === "object") {
      if ("import" in node) return true;
      return Object.values(node).some((n) => hasImport(n, depth + 1));
    }
    return false;
  };
  if (hasImport(ex)) return "esm";
  return "cjs";
}

// Types-only packages (@types/*, type-fest, undici-types) ship nothing but .d.ts
// and have no loadable JS entry point, so they fail on every runtime for a reason
// that has nothing to do with runtime compatibility. Flag them structurally so the
// summary can report them separately instead of scoring them as compat failures.
function hasRuntimeEntry(pkgJson, pkgDir) {
  if (!pkgJson) return false;
  if (typeof pkgJson.main === "string" && pkgJson.main.trim()) return true;
  if (typeof pkgJson.module === "string" && pkgJson.module.trim()) return true;

  let found = false;
  const walk = (node, inTypes, depth = 0) => {
    if (found || depth > 8) return;
    if (typeof node === "string") {
      // .json deliberately excluded: nearly every exports map contains
      // "./package.json": "./package.json", which is not a code entry point.
      if (!inTypes && /\.(js|cjs|mjs|node)$/i.test(node)) found = true;
      return;
    }
    if (Array.isArray(node)) return node.forEach((x) => walk(x, inTypes, depth + 1));
    if (node && typeof node === "object") {
      for (const [k, v] of Object.entries(node)) {
        if (k === "./package.json") continue;
        walk(v, inTypes || k === "types", depth + 1);
      }
    }
  };
  if (pkgJson.exports) walk(pkgJson.exports, false);
  if (found) return true;

  return fs.existsSync(path.join(pkgDir, "index.js"));
}

const installed = fs
  .readFileSync("/work/install.jsonl", "utf8")
  .trim().split("\n").filter(Boolean)
  .map((l) => JSON.parse(l))
  .filter((r) => r.install_ok);

console.log(`probing ${installed.length} packages x ${RUNTIMES.length} runtimes`);

// Record exact runtime versions from inside the container.
const versions = {};
for (const rt of RUNTIMES) {
  const v = await run(rt.cmd, rt.key === "deno" ? ["--version"] : ["--version"], {}, 20000);
  versions[rt.key] = (v.stdout || v.stderr).trim().split("\n")[0];
  if (rt.key.startsWith("bun")) {
    const rev = await run(rt.cmd, ["--revision"], {}, 20000);
    versions[rt.key + "_revision"] = (rev.stdout || rev.stderr).trim();
  }
}
fs.writeFileSync("/work/versions.json", JSON.stringify(versions, null, 2));
console.log(JSON.stringify(versions, null, 2));

const out = fs.createWriteStream("/work/results.jsonl", { flags: "w" });
const dirFor = (name) => name.replace(/^@/, "at-").replace(/\//g, "__");

let done = 0;
async function probeOne(rec) {
  const dir = path.join(ROOT, dirFor(rec.package));
  fs.writeFileSync(path.join(dir, "__probe.mjs"), PROBE_SRC);
  let pkgJson = null;
  try {
    pkgJson = JSON.parse(
      fs.readFileSync(path.join(dir, "node_modules", ...rec.package.split("/"), "package.json"), "utf8")
    );
  } catch {}

  const row = {
    rank: rec.rank,
    package: rec.package,
    version: rec.version,
    weekly_downloads: rec.weeklyDownloads,
    entry_type: entryType(pkgJson),
    has_runtime_entry: hasRuntimeEntry(pkgJson, path.join(dir, "node_modules", ...rec.package.split("/"))),
  };

  for (const rt of RUNTIMES) {
    const r = await run(rt.cmd, rt.args, { cwd: dir, env: { ...process.env, PROBE_PKG: rec.package } }, TIMEOUT_MS);
    const okLine = /PROBE_OK (import|require)/.exec(r.stdout || "");
    let result, errClass = "", via = "";
    if (r.timedOut) {
      result = "timeout";
    } else if (r.code === 0 && okLine) {
      result = "ok";
      via = okLine[1];
    } else {
      result = "fail";
      errClass = classify(r.stderr);
    }
    row[`${rt.key}_result`] = result;
    row[`${rt.key}_err_class`] = errClass;
    row[`${rt.key}_via`] = via;
    row[`${rt.key}_err`] = result === "fail" ? (r.stderr || "").slice(0, 600) : "";

    if (result === "fail") {
      // Both attempts are considered: if either got the module executing, the
      // package's top-level code ran. Take the furthest stage reached.
      const impErr = parseProbeErr(r.stderr, "PROBE_ERR_IMPORT");
      const reqErr = parseProbeErr(r.stderr, "PROBE_ERR_REQUIRE");
      const stages = [deliveryStage(impErr), deliveryStage(reqErr)].filter(Boolean);
      row[`${rt.key}_delivery`] = stages.length
        ? stages.reduce((a, b) => (STAGE[b] > STAGE[a] ? b : a))
        : "unknown";
      row[`${rt.key}_err_name`] = impErr.name;
      row[`${rt.key}_err_code`] = impErr.code;
    } else {
      row[`${rt.key}_delivery`] = result === "ok" ? "executed" : "";
      row[`${rt.key}_err_name`] = "";
      row[`${rt.key}_err_code`] = "";
    }
  }

  out.write(JSON.stringify(row) + "\n");
  done++;
  if (done % 25 === 0 || done === installed.length) console.log(`probe ${done}/${installed.length}`);
}

const queue = [...installed];
const workers = Array.from({ length: Math.min(CONC, queue.length) }, async () => {
  while (queue.length) await probeOne(queue.shift());
});
await Promise.all(workers);
out.end();
console.log("PROBE DONE");
