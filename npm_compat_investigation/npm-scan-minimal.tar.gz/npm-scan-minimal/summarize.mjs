// Phase 3: aggregate results.jsonl -> summary.json + results.csv
// Three arms: Node.js, Deno, Bun. Produces the paper's figures — packages scored,
// the conservative "load with no error on all three" rate, the "execute top-level
// code on all three" delivery rate, cross-runtime uniformity, and the denominators.
import fs from "node:fs";
import path from "node:path";

const DIR = process.argv[2] || "/work";
const rows = fs.readFileSync(path.join(DIR, "results.jsonl"), "utf8")
  .trim().split("\n").filter(Boolean).map((l) => JSON.parse(l));
const installRows = fs.readFileSync(path.join(DIR, "install.jsonl"), "utf8")
  .trim().split("\n").filter(Boolean).map((l) => JSON.parse(l));
const versions = JSON.parse(fs.readFileSync(path.join(DIR, "versions.json"), "utf8"));

const ARMS = ["node", "deno", "bun"];

// Packages with no loadable JS entry point (types-only: @types/*, type-fest,
// undici-types, csstype) cannot execute on any runtime by construction. Reported
// but excluded from the compat denominator.
const noEntry = rows.filter((r) => r.has_runtime_entry === false);
const scored = rows.filter((r) => r.has_runtime_entry !== false);
const n = scored.length;
const pct = (k, d = n) => (d === 0 ? 0 : Number(((k / d) * 100).toFixed(2)));
const isOk = (r, a) => r[`${a}_result`] === "ok";

const perArm = {};
for (const a of ARMS) {
  const ok = scored.filter((r) => isOk(r, a)).length;
  const fail = scored.filter((r) => r[`${a}_result`] === "fail").length;
  const timeout = scored.filter((r) => r[`${a}_result`] === "timeout").length;
  const classes = {};
  for (const r of scored) {
    if (r[`${a}_result`] === "fail") {
      const c = r[`${a}_err_class`] || "other";
      classes[c] = (classes[c] || 0) + 1;
    }
  }
  perArm[a] = { ok, fail, timeout, ok_pct: pct(ok), failure_classes: classes };
}

// The conservative headline: loads with NO error under all three runtimes.
const allThree = scored.filter((r) => ARMS.every((a) => isOk(r, a))).length;

const nodeOk = scored.filter((r) => isOk(r, "node"));
const givenNodeOk = {
  n_node_ok: nodeOk.length,
  also_deno_pct: pct(nodeOk.filter((r) => isOk(r, "deno")).length, nodeOk.length),
  also_bun_pct: pct(nodeOk.filter((r) => isOk(r, "bun")).length, nodeOk.length),
  also_deno_and_bun_pct: pct(nodeOk.filter((r) => isOk(r, "deno") && isOk(r, "bun")).length, nodeOk.length),
};

// Packages that fail identically on every runtime are failing for reasons intrinsic
// to the package (no root export, deliberate refusal, missing peer dep), not any
// runtime's compat layer. Split them out; the claim is about cross-runtime uniformity.
const failedAllArms = scored.filter((r) => ARMS.every((a) => !isOk(r, a)));
const structural = failedAllArms.filter((r) =>
  /ERR_PACKAGE_PATH_NOT_EXPORTED|No "exports" main defined|cannot be imported/i.test(r.node_err || "")
);

// Divergence = any arm disagrees with any other. 1 - this is the uniformity metric.
const divergentAll = scored.filter((r) => new Set(ARMS.map((a) => r[`${a}_result`])).size > 1);

const entryTypes = {};
for (const r of scored) entryTypes[r.entry_type] = (entryTypes[r.entry_type] || 0) + 1;

const summary = {
  generated: new Date().toISOString(),
  method: "npm install --ignore-scripts into per-package dirs; identical node_modules loaded under each runtime via dynamic import() with require() fallback; 30s timeout; --network none during load",
  runtime_versions: versions,
  n_attempted: installRows.length,
  n_installed_ok: installRows.filter((r) => r.install_ok).length,
  n_install_failed_platform: installRows.filter((r) => r.install_err_class === "platform").length,
  n_install_failed_other: installRows.filter((r) => !r.install_ok && r.install_err_class !== "platform").length,
  install_failures: installRows.filter((r) => !r.install_ok)
    .map((r) => ({ package: r.package, class: r.install_err_class })),
  n_probed: rows.length,
  n_no_runtime_entry: noEntry.length,
  no_runtime_entry_packages: noEntry.map((r) => r.package),
  n_scored: n,
  entry_types: entryTypes,
  per_runtime: perArm,
  headline: {
    // conservative compatibility claim
    load_clean_all_three: { n: allThree, pct: pct(allThree) },
  },
  given_node_ok: givenNodeOk,
  // For the delivery claim a package whose top-level code ran and *then* threw has
  // still executed attacker code, so report that reach separately from the headline.
  execution_reach: (() => {
    const o = {};
    for (const a of ARMS) {
      const d = (k) => scored.filter((r) => r[`${a}_delivery`] === k).length;
      const executed = d("executed"), threw = d("executed_then_threw");
      o[a] = {
        loaded_clean: executed,
        executed_then_threw: threw,
        located_not_executed: d("located_not_executed"),
        not_located: d("not_located"),
        got_control: executed + threw,
        got_control_pct: pct(executed + threw),
      };
    }
    const allGot = scored.filter((r) =>
      ARMS.every((a) => ["executed", "executed_then_threw"].includes(r[`${a}_delivery`]))
    ).length;
    o.all_three_got_control = { n: allGot, pct: pct(allGot) };
    return o;
  })(),
  uniformity: {
    n_failed_on_every_arm: failedAllArms.length,
    n_of_those_structural: structural.length,
    structural_packages: structural.map((r) => r.package),
    n_divergent_any_arm: divergentAll.length,
    pct_identical_across_arms: pct(n - divergentAll.length),
    divergent_packages: divergentAll.map((r) => ({
      package: r.package,
      ...Object.fromEntries(ARMS.map((a) => [a, r[`${a}_result`]])),
    })),
  },
};

fs.writeFileSync(path.join(DIR, "summary.json"), JSON.stringify(summary, null, 2));

const cols = ["rank", "package", "version", "weekly_downloads", "entry_type", "has_runtime_entry",
  ...ARMS.map((a) => `${a}_result`), ...ARMS.map((a) => `${a}_err_class`)];
const esc = (v) => {
  const s = v === undefined || v === null ? "" : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
fs.writeFileSync(
  path.join(DIR, "results.csv"),
  [cols.join(","), ...rows.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n") + "\n"
);

console.log(JSON.stringify(summary, null, 2));
